// 译点云端代理配置
// 先在 Render 部署本压缩包内的 Python 后端，再把 Render 分配的 HTTPS 域名填在下面。
// 示例格式：https://yidian-translator-xxxx.onrender.com
// 不要在这里填写 /api/fetch 或 /api/health。
window.YIDIAN_BACKEND_URL = "https://YOUR-RENDER-SERVICE.onrender.com";
