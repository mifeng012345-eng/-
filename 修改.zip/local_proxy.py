# -*- coding: utf-8 -*-
"""译点：本地/云端同源代理。仅使用 Python 标准库。"""
import json
import os
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PAGE = "index.html"
PORT = int(os.environ.get("PORT", "8765"))
# 本地双击启动时仅监听本机；云平台设置 PORT 后监听容器网卡。
HOST = "0.0.0.0" if os.environ.get("PORT") else "127.0.0.1"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")

# 只允许代理已知翻译服务。自定义 API 域名需在部署环境变量中明确添加：
# ALLOWED_PROXY_HOSTS=api.example.com,api.openai.com
DEFAULT_ALLOWED_HOSTS = {
    "api.mymemory.translated.net",
    "translate.googleapis.com",
    "translate.disroot.org",
    "dict.youdao.com",
}
EXTRA_ALLOWED_HOSTS = {
    x.strip().lower()
    for x in os.environ.get("ALLOWED_PROXY_HOSTS", "").split(",")
    if x.strip()
}
ALLOWED_HOSTS = DEFAULT_ALLOWED_HOSTS | EXTRA_ALLOWED_HOSTS
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MIME_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # 不打印用户翻译内容、请求参数或 API 密钥
        pass

    def send_bytes(self, status, data, content_type="application/json; charset=utf-8",
                   extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        # Toy 页面与 Render 后端是不同域名，需要 CORS。
        # 不携带 Cookie；代理目标域名仍由 ALLOWED_HOSTS 严格限制。
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Max-Age", "86400")
        self.send_header("Vary", "Origin")
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_error_json(self, status, message):
        data = json.dumps({"error": message}, ensure_ascii=False).encode("utf-8")
        self.send_bytes(status, data)

    def get_target(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)
        return (query.get("url") or [""])[0]

    def forward(self, method):
        target = self.get_target()
        try:
            parsed = urllib.parse.urlparse(target)
            host = (parsed.hostname or "").lower().rstrip(".")
            if parsed.scheme != "https" or not host or host not in ALLOWED_HOSTS:
                self.send_error_json(403, "目标接口不在允许列表中。自定义域名请配置 ALLOWED_PROXY_HOSTS。")
                return
            if parsed.username or parsed.password or parsed.port not in (None, 443):
                self.send_error_json(403, "不允许使用凭证或非标准端口。")
                return

            length = int(self.headers.get("Content-Length") or 0)
            if length > 1_000_000:
                self.send_error_json(413, "请求内容过大")
                return
            body = self.rfile.read(length) if method == "POST" and length else None
            headers = {"User-Agent": UA, "Accept": "*/*"}
            content_type = self.headers.get("Content-Type")
            authorization = self.headers.get("Authorization")
            if content_type:
                headers["Content-Type"] = content_type
            if authorization:
                headers["Authorization"] = authorization

            req = urllib.request.Request(target, data=body, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=25) as response:
                data = response.read(2_000_000)
                ctype = response.headers.get("Content-Type", "application/json; charset=utf-8")
                self.send_bytes(response.status, data, ctype)
        except urllib.error.HTTPError as exc:
            data = exc.read(1_000_000) or b'{"error":"upstream error"}'
            ctype = exc.headers.get("Content-Type", "application/json; charset=utf-8")
            self.send_bytes(exc.code, data, ctype)
        except Exception as exc:
            # 仅返回错误类型/短信息，不记录原文
            self.send_error_json(502, "上游翻译服务连接失败：" + str(exc)[:160])

    def serve_static(self, head_only=False):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if path in ("", "/"):
            path = "/" + PAGE
        relative = path.lstrip("/")
        full = os.path.realpath(os.path.join(BASE_DIR, relative))
        if os.path.commonpath([BASE_DIR, full]) != BASE_DIR or not os.path.isfile(full):
            self.send_bytes(404, b"404 Not Found", "text/plain; charset=utf-8")
            return
        ext = os.path.splitext(full)[1].lower()
        with open(full, "rb") as f:
            data = f.read()
        self.send_bytes(200, data, MIME_TYPES.get(ext, "application/octet-stream"))

    def do_GET(self):
        if self.path == "/api/health":
            payload = json.dumps({"ok": True, "service": "yidian-proxy", "version": 2}).encode("utf-8")
            self.send_bytes(200, payload, "application/json; charset=utf-8",
                            {"X-Yidian-Proxy": "ready"})
        elif self.path.startswith("/api/fetch?"):
            self.forward("GET")
        else:
            self.serve_static()

    def do_POST(self):
        if self.path.startswith("/api/fetch?"):
            self.forward("POST")
        else:
            self.send_bytes(404, b"404 Not Found", "text/plain; charset=utf-8")

    def do_HEAD(self):
        if self.path.startswith("/api/fetch?"):
            self.forward("HEAD")
        else:
            self.serve_static(head_only=True)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Max-Age", "86400")
        self.send_header("Content-Length", "0")
        self.end_headers()

def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("译点服务已启动：http://%s:%s/" % (HOST, PORT))
    print("代理允许的域名：%s" % ", ".join(sorted(ALLOWED_HOSTS)))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
